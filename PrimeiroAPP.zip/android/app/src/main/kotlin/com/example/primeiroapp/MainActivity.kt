package com.example.primeiroapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
